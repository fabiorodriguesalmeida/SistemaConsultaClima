Depois de extrair o zip.

1) Clicar na Pasta Sistema de Consulta de Clima;
2) Depois clicar na pasta ClientApp;
3) Abrir o cmd e ir na pasta ClientApp e executar o comando: npm i node-modules 
4) Será instalada a pasta node_modules
5) Mudar no appsettings.json - Na linha 3: Mudar o nome do Server de FABIO-PC para o dá máquina que irá realizar o teste.
6) Mudar no ClimaTempoSimplesContext.cs - Na linha 28: Mudar o nome do Server de FABIO-PC para o dá máquina que irá realizar o teste.