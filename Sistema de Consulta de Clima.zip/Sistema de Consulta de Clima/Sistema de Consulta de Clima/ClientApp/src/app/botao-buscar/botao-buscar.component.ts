import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-botao-buscar',
  templateUrl: './botao-buscar.component.html',
  styleUrls: ['./botao-buscar.component.css']
})

export class BotaoBuscarComponent {

  cidadeEscolhida = '';
  baseUrlSelecionada = '';

  public buscarCidade: BuscarCidade[];
  
  constructor(private http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
  }

  botaoBuscarCidade(cidadeSelecionada) {
    this.cidadeEscolhida = cidadeSelecionada;

    if (cidadeSelecionada !== "") {
      this.http.get<BuscarCidade[]>(this.baseUrlSelecionada + 'Home/buscarCidade' + '/?cidade=' + this.cidadeEscolhida).subscribe(result => {
        this.buscarCidade = result;

        if (this.buscarCidade.length == 0) {
          alert("Cidade não encontrada! Pesquisar outra por favor.")
        }
      }), error => console.error(error);
    }
  }
}

interface BuscarCidade {
  dataPrevisao: string;
  diaSemana: string;
  cidade: string;
  clima: string;
  temperaturaMinima: number;
  temperaturaMaxima: number;
}
