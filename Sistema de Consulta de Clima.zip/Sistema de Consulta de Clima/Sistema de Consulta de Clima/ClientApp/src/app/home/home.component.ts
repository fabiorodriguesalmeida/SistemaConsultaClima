import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})


export class HomeComponent {
  /*public previsaoClima: PrevisaoClima[];

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    http.get<PrevisaoClima[]>(baseUrl + 'Home').subscribe(result => {
      this.previsaoClima = result;
    }), error => console.error(error);
  }*/
}


interface PrevisaoClima {
  cidade: string;
  uf: string;
  temperaturaMaxima: number;
}



