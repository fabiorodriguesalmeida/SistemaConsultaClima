import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-cidade-quente',
  templateUrl: './cidade-quente.component.html',
  styleUrls: ['./cidade-quente.component.css']
})


export class CidadeQuenteComponent {
  public cidadeQuente: CidadeQuente[];

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    http.get<CidadeQuente[]>(baseUrl + 'Home/cidadeQuente').subscribe(result => {
      this.cidadeQuente = result;
    }), error => console.error(error);
  }
}


interface CidadeQuente {
  cidade: string;
  uf: string;
  temperaturaMaxima: number;
}



