import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-cidade-fria',
  templateUrl: './cidade-fria.component.html',
  styleUrls: ['./cidade-fria.component.css']
})


export class CidadeFriaComponent {
  public cidadeFria: CidadeFria[];

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    http.get<CidadeFria[]>(baseUrl + 'Home/cidadeFria').subscribe(result => {
      this.cidadeFria = result;
    }), error => console.error(error);
  }
}


interface CidadeFria {
  cidade: string;
  uf: string;
  temperaturaMinima: number;
}



