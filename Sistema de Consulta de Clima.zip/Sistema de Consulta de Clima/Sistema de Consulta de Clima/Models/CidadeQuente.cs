﻿using System;
using System.Collections.Generic;

namespace Sistema_de_Consulta_de_Clima.Models
{
    public partial class CidadeQuente
    {
        public string Cidade { get; set; }
        public string UF { get; set; }
        public decimal? TemperaturaMaxima { get; set; }
        
    }
}