﻿using System;
using System.Collections.Generic;

namespace Sistema_de_Consulta_de_Clima.Models
{
    public partial class CidadeBuscada
    {
        public string Cidade { get; set; }
        public DateTime DataPrevisao { get; set; }
        public string DiaSemana { get; set; }
        public string Clima { get; set; }
        public decimal? TemperaturaMinima { get; set; }
        public decimal? TemperaturaMaxima { get; set; }

    }
}