﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Sistema_de_Consulta_de_Clima.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace Sistema_de_Consulta_de_Clima.Controllers
{
    [ApiController]
    [Route("[Controller]")]
    public class HomeController : ControllerBase
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ClimaTempoSimplesContext _climaTempoSimplesContext;

        public HomeController(ILogger<HomeController> logger, ClimaTempoSimplesContext climaTempoSimplesContext)
        {
            _logger = logger;
            _climaTempoSimplesContext = climaTempoSimplesContext;
        }

        [HttpGet("cidadeQuente")]
        public List<CidadeQuente> cidadeQuente()
        {
            var cidadeQuente = (from pc in _climaTempoSimplesContext.PrevisaoClimas
                                join c in _climaTempoSimplesContext.Cidades on pc.CidadeId equals c.Id
                                join e in _climaTempoSimplesContext.Estados on c.EstadoId equals e.Id
                                where pc.DataPrevisao == DateTime.Now.Date
                                orderby pc.TemperaturaMaxima descending
                                select new CidadeQuente
                                {
                                    Cidade = c.Nome,
                                    UF = e.Uf,
                                    TemperaturaMaxima = pc.TemperaturaMaxima
                                }).Take(3).ToList();

            return cidadeQuente;
        }

        [HttpGet("cidadeFria")]
        public List<CidadeFria> cidadeFria()
        {
            var cidadeFria = (from pc in _climaTempoSimplesContext.PrevisaoClimas
                              join c in _climaTempoSimplesContext.Cidades on pc.CidadeId equals c.Id
                              join e in _climaTempoSimplesContext.Estados on c.EstadoId equals e.Id
                              where pc.DataPrevisao == DateTime.Now.Date
                              orderby pc.TemperaturaMinima ascending
                              select new CidadeFria
                              {
                                  Cidade = c.Nome,
                                  UF = e.Uf,
                                  TemperaturaMinima = pc.TemperaturaMinima
                              }).Take(3).ToList();

            return cidadeFria;
        }

        [HttpGet("buscarCidade")]
        public List<CidadeBuscada> buscar(string cidade)
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("pt-Br");

            var buscarCidade = (from pc in _climaTempoSimplesContext.PrevisaoClimas
                                join c in _climaTempoSimplesContext.Cidades on pc.CidadeId equals c.Id
                                where ((pc.DataPrevisao >= DateTime.Now.Date.AddDays(1) && pc.DataPrevisao <= DateTime.Now.Date.AddDays(7)) && c.Nome == cidade)
                                orderby pc.DataPrevisao ascending
                                select new CidadeBuscada
                                {
                                    Cidade = c.Nome,
                                    DataPrevisao = pc.DataPrevisao,
                                    DiaSemana = pc.DataPrevisao.ToString("dddd"),
                                    Clima = pc.Clima,
                                    TemperaturaMaxima = pc.TemperaturaMaxima,
                                    TemperaturaMinima = pc.TemperaturaMinima
                                }).ToList();

            return buscarCidade;
        }
    }
}