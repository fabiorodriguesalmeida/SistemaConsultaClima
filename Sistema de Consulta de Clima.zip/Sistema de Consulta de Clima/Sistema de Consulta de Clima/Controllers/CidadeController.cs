﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Sistema_de_Consulta_de_Clima.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Sistema_de_Consulta_de_Clima.Controllers
{
    [ApiController]
    [Route("[Controller]")]
    public class CidadeController : ControllerBase
    {
        private readonly ILogger<CidadeController> _logger;
        private readonly ClimaTempoSimplesContext _climaTempoSimplesContext;

        public CidadeController(ILogger<CidadeController> logger, ClimaTempoSimplesContext climaTempoSimplesContext)
        {
            _logger = logger;
            _climaTempoSimplesContext = climaTempoSimplesContext;
        }

        [HttpGet]
        public List<CidadeQuente> cidadeQuente()
        {
            var cidadeQuente = (from pc in _climaTempoSimplesContext.PrevisaoClimas
                                join c in _climaTempoSimplesContext.Cidades on pc.CidadeId equals c.Id
                                join e in _climaTempoSimplesContext.Estados on c.EstadoId equals e.Id
                                where pc.DataPrevisao == DateTime.Now.Date
                                select new CidadeQuente
                                {
                                    Cidade = c.Nome,
                                    UF = e.Uf,
                                    TemperaturaMaxima = pc.TemperaturaMaxima
                                }).Take(3).ToList();

            return cidadeQuente;
        }

        [HttpGet]
        public List<CidadeFria> cidadeFria()
        {
            var cidadeFria = (from pc in _climaTempoSimplesContext.PrevisaoClimas
                              join c in _climaTempoSimplesContext.Cidades on pc.CidadeId equals c.Id
                              join e in _climaTempoSimplesContext.Estados on c.EstadoId equals e.Id
                              where pc.DataPrevisao == DateTime.Now.Date
                              select new CidadeFria
                              {
                                  Cidade = c.Nome,
                                  UF = e.Uf,
                                  TemperaturaMinima = pc.TemperaturaMinima
                              }).Take(3).ToList();

            return cidadeFria;
        }
    }
}